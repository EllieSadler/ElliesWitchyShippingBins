# Ellie's Witchy Shipping Bins

This mod replaces the existing shipping bin with a more witch-friendly version.

You can optionally add decorations to the shipping bin. "Purple Eyes" and "Yellow Eyes" animate when you put items in the shipping bin.
